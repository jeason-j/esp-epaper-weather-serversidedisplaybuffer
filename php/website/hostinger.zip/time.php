<html>
<body>
<p><?php  
echo "\n";
date_default_timezone_set("Asia/Shanghai");
echo "DATE:".date("D,d M Y H:i:s");
echo "\n";
?> </p>

</body>
</html>
